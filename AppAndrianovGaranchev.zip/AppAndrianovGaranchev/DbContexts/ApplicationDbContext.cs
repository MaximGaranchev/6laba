﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AndrianovGaranchev.Entities;
using System.Windows.Controls;

namespace AndrianovGaranchev.DbContexts;

public class ApplicationDbContext : DbContext
{


    public DbSet<User> Users { get; set; } = null!;
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(userConfiguration=>
        {
            userConfiguration.HasKey(u => u.Id);

            userConfiguration
                .Property(u => u.UserName)
                .HasMaxLength(32);
            userConfiguration
                .HasIndex(u => u.UserName)
                .IsUnique();
        });
    }



    protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
    {
        optionBuilder.UseMySql(
            "server=localhost;database=laba6AndianovGaranchev;user=root;password=123456789;",
            new MySqlServerVersion(new Version(8, 0, 40)));

    }
}
